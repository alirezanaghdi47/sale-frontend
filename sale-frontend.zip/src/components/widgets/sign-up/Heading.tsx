'use client';

const Heading = () => {

    return (
        <div className="flex justify-between items-center gap-x-2 w-full">
            <h3 className="text-lg text-gray font-bold">
                عضویت
            </h3>
        </div>
    )
}

export default Heading;