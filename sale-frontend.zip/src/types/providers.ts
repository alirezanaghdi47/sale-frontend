// libraries
import React from "react";

export type NextAuthProviderType = {
    children: React.ReactNode
}

export type ReactCookieProviderType = {
    children: React.ReactNode
}

export type TanstackProviderType = {
    children: React.ReactNode
}