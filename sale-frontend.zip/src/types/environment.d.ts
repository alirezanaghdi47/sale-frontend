declare var process : {
    env: {
        NODE_ENV: string,
        BASE_URL: string,
        API_URL: string,
        NEXTAUTH_URL: string,
        NEXTAUTH_SECRET: string,
    }
}