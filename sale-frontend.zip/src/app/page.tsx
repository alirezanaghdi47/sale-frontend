// libraries
import {redirect} from "next/navigation";

const HomePage = () => redirect("/advertises");

export default HomePage;